
package com.electronic.genfarma;

/**
 *
 * @author Prateek
 */
public class FSO {

    public static String FSOName() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public static String FSOEmail() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public static String FSOPhone() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getFsoID() {
        return FsoID;
    }

    public void setFsoID(int FsoID) {
        this.FsoID = FsoID;
    }

    public String getFsoName() {
        return FsoName;
    }

    public void setFsoName(String FsoName) {
        this.FsoName = FsoName;
    }

    public String getFsoAddress() {
        return FsoAddress;
    }

    public void setFsoAddress(String FsoAddress) {
        this.FsoAddress = FsoAddress;
    }

    public int getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(int phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }
    int FsoID;
    String FsoName;
    String FsoAddress;
    int phoneNo;
    String Email;
    int empID;

    public int getEmpID() {
        return empID;
    }

    public void setEmpID(int empID) {
        this.empID = empID;
    }
}
