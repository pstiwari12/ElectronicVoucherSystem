/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.niit.gniitproject;

import com.electronic.genfarma.DepartmentalManager;
import com.niit.EVS.DAO.DepartmentalManagerDAO;

import java.util.List;

/**
 *
 * @author MRuser
 */
public class ApplicationClass {
    public static void main(String[] args){
       DepartmentalManagerDAO dmDAO = (DepartmentalManagerDAO) new DepartmentalManagerImpl();
        int count = dmDAO.addDepartmentalManager(new DepartmentalManager(6,"Rohan","rohan@niit.com"));
        if(count>0)System.out.println("Record Added Successfully");
        else System.out.println("Record Failed to get added");
//        count=employeeDAO.deleteEmployee(1);
//        if(count>0)System.out.println("Record Deleted Successfully");
//        else System.out.println("Record Failed to get deleted");
//        Employee employee = new Employee(2,"sonam","sonam@gmail.com");
//        count=employeeDAO.updateEmployee(2, employee);
//        if(count>0)System.out.println("Record Updated Successfully");
//        else System.out.println("Record Failed to get updated");
        List<DepartmentalManager> dmlist = dmDAO.getAllDepartmentalManager();
        for(DepartmentalManager dm : dmlist){
            System.out.println(dm.getDMID() + "|" + emp.getDMName() + "|" + dm.getEmail());
        }
        DepartmentalManager dm = dmDAO.getDepartmentalManagerByID(3);
            System.out.println(dm.getDMID() + "|" +DepartmentalManager.getDMName() + "|" + dm.getEmail());
    }
}
