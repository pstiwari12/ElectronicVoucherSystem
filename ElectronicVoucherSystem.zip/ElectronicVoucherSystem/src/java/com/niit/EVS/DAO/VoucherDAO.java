/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.niit.EVS.DAO;

import com.electronic.genfarma.Voucher;
import java.util.List;

/**
 *
 * @author Prateek
 */
public interface VoucherDAO {
    int Voucher (Voucher voucher);
   int deleteVoucher(int VocherID);
   List<Voucher> getVoucher();
   Voucher getVoucherByID(int VoucherID);
   int updateVoucher(int VoucherID, Voucher voucher);
    
}
