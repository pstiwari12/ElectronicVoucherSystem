/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.niit.EVS.DAO;

import com.electronic.genfarma.FSO;
import java.util.List;

/**
 *
 * @author Prateek
 */
public interface FSODAO {
    int FSO (FSO fso);
   int deleteFSO(int fsoID);
   List<FSO> getFSO();
   FSO getFSOByID(int fsoID);
   int updateFSO(int fsoID, FSO fso);
    
}
