/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.niit.EVS.DAOImpl;

import com.electronic.genfarma.Employee;
import com.niit.EVS.DAO.EmployeeDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Prateek
 */
public class EmployeeDAOImpl implements EmployeeDAO  {
    Connection con = DataBaseConnection.getConnection();
    public int addCustomer(Employee employee) {
        
        
    try {
      PreparedStatement psmt = con.prepareStatement("Insert Employee(EmpID,EmpName,EmpEmail,EmpPhone,EmpAccountNo) Values(?,?,?,?,?)");
        psmt.setString(1,employee.EmpID());
        psmt.setString(2,employee.EmpName());
        psmt.setString(3,employee.getEmpEmail());
        psmt.setInt(4,employee.getEmpPhone());
        psmt.setString(5,employee.getEmpAccountNo());
        
    } catch (SQLException ex) {
        Logger.getLogger(EmployeeDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
    }
   return 0;

    }
    @Override
    public int Employee(com.electronic.genfarma.Employee employee) {
    return 0;   
    }

    @Override
    public int deleteEmployee(int employeeID) {
       return 0;
    }

    @Override
    public List<com.electronic.genfarma.Employee> getEmployee() {
    return null;
    }

    @Override
    public com.electronic.genfarma.Employee getEmployeeByID(int employeeID) {
    return null;
    }

    @Override
    public int updateEmployee(int employeeID, com.electronic.genfarma.Employee employee) {
    return 0;
    }
    
    
}
