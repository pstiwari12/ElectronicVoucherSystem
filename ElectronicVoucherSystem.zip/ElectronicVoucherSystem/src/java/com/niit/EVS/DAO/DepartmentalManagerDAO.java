/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.niit.EVS.DAO;

import com.electronic.genfarma.DepartmentalManager;
import java.util.List;

/**
 *
 * @author Prateek
 */
public interface DepartmentalManagerDAO {
    int DepartmentalManager (DepartmentalManager dm);
   int deleteDepartmentalManager(int dmID);
   List<DepartmentalManager> getDepartmentalManager();
   DepartmentalManager getDepartmentalManagerByID(int dmID);
   int updateDepartmentalManager(int dmID, DepartmentalManager dm);

    public int addDepartmentalManager(DepartmentalManager departmentalManager);
    
}
