/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.niit.EVS.DAOImpl;

import com.electronic.genfarma.DepartmentalManager;
import com.niit.EVS.DAO.DepartmentalManagerDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Prateek
 */
public abstract class DepartmentalManagerDAOImpl implements DepartmentalManagerDAO {
Connection con = DataBaseConnection.getConnection();
    @Override
    public int DepartmentalManager(com.electronic.genfarma.DepartmentalManager dm) {
        try {
      PreparedStatement psmt = con.prepareStatement("Insert DepartmentalManager(DMName,DMEmail,DMPhone) Values(?,?,?)");
        psmt.setString(1,DepartmentalManager.DMID());
        psmt.setString(2,DepartmentalManager.DMName());
        psmt.setString(3,DepartmentalManager.DMEmail());
        psmt.setInt(4,DepartmentalManager.getDMPhone());

        
    } catch (SQLException ex) {
        Logger.getLogger(EmployeeDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
    }
   return 0;
    }

    @Override
    public int deleteDepartmentalManager(int dmID) {
    int count=0;
        try {
            
            Connection connection = DataBaseConnection.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement("delete from DepartmentalManager where DMID=?");
        int DMID = 0;
            preparedStatement.setInt(1,DMID);
            count=preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DepartmentalManagerDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return count;
    }
    

    @Override
    public List<com.electronic.genfarma.DepartmentalManager> getDepartmentalManager() {
   List<DepartmentalManager> DepartmentalManagerList = null;
   try {
            Connection connection = DataBaseConnection.getConnection(); 
            PreparedStatement preparedStatement = connection.prepareStatement("select * from DepartmentalManager");
            ResultSet resultSet = preparedStatement.executeQuery();
            DepartmentalManagerList = new ArrayList<>();
            if(resultSet!=null){
                //resultSet.first();
                while(resultSet.next()){
                    int DMId = resultSet.getInt(1);
                    String DMName = resultSet.getString(2);
                    String DMEmail = resultSet.getString(3);
                    DepartmentalManager DM = new DepartmentalManager(DMId,DMName,DMEmail);
                    DepartmentalManager DepartmentalManager = null;
                    DepartmentalManagerList.add(DepartmentalManager);
                }
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(EmployeeDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
     return DepartmentalManagerList;
    }


    @Override
    public com.electronic.genfarma.DepartmentalManager getDepartmentalManagerByID(int dmID) {
   List<DepartmentalManager> DepartmentalManagerList = null;
        try {
            Connection connection = DataBaseConnection.getConnection(); 
            PreparedStatement preparedStatement = connection.prepareStatement("select * from DepartmentalManager where DMID=?");
       int DMID = 0;
            preparedStatement.setInt(1, DMID);
            ResultSet resultSet = preparedStatement.executeQuery();
            DepartmentalManagerList = new ArrayList<>();
            if(resultSet!=null){
                //resultSet.first();
                while(resultSet.next()){
                    int DepartmentalManagerID = resultSet.getInt(1);
                    String DMName = resultSet.getString(2);
                    String DMEmail = resultSet.getString(3);
                    DepartmentalManager DM = new DepartmentalManager(DMID,DMName,DMEmail);
                    DepartmentalManager DepartmentalManager = null;
                   DepartmentalManagerList.add(DepartmentalManager);
                }
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(EmployeeDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
     if(DepartmentalManager.size()>0) return DepartmentalManagerList.get(0);
     else return null;
    }
    

    @Override
    public int updateDepartmentalManager(int dmID, com.electronic.genfarma.DepartmentalManager dm) {
   int count=0;
        try {
            Connection connection  = DataBaseConnection.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement("update DepartmentalManager set DMname=?, DMemail=? where DMid=?");
            preparedStatement.setString(1,DepartmentalManager.getDMName());
            preparedStatement.setString(2,DepartmentalManager.getDMEmail());
       int DMID = 0;
            preparedStatement.setInt(3,DMID);
            count=preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(EmployeeDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return count;
    }
    
}

    
   

