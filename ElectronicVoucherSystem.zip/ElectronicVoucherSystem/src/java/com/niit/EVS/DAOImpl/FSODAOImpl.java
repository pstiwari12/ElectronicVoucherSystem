/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.niit.EVS.DAOImpl;

import com.electronic.genfarma.FSO;
import com.niit.EVS.DAO.FSODAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Prateek
 */
public class FSODAOImpl implements FSODAO{
Connection con = DataBaseConnection.getConnection();
    @Override
    public int FSO(com.electronic.genfarma.FSO fso) {
    try {
      PreparedStatement psmt = con.prepareStatement("Insert FSO(FSOName,FSOEmail,FSOPhone) Values(?,?,?)");
        psmt.setString(1,FSO.FSOName());
        psmt.setString(2,FSO.FSOEmail());
        psmt.setString(3,FSO.FSOPhone());
       
        
    } catch (SQLException ex) {
        Logger.getLogger(EmployeeDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
    }
   return 0;
    }

    @Override
    public int deleteFSO(int fsoID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<FSO> getFSO() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public FSO getFSOByID(int fsoID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int updateFSO(int fsoID, FSO fso) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    }

    