/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.niit.EVS.DAOImpl;

import com.electronic.genfarma.Voucher;
import com.niit.EVS.DAO.VoucherDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Prateek
 */
public class VoucherDAOImpl implements VoucherDAO{
Connection con = DataBaseConnection.getConnection();
    @Override
    public int Voucher(com.electronic.genfarma.Voucher voucher) {
    try {
      PreparedStatement psmt = con.prepareStatement("Insert Voucher(VoucherName,StartDate,EndDate) Values(?,?,?)");
        psmt.setString(1,Voucher.VoucherName());
        psmt.setString(2,Voucher.StartDate());
        psmt.setString(3,Voucher.EndDate());
       
        
    } catch (SQLException ex) {
        Logger.getLogger(EmployeeDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
    }
   return 0;
    }

    @Override
    public int deleteVoucher(int VocherID) {
    return 0;
    }

    @Override
    public List<com.electronic.genfarma.Voucher> getVoucher() {
    return null;
    }

    @Override
    public com.electronic.genfarma.Voucher getVoucherByID(int VoucherID) {
    return null;
    }

    @Override
    public int updateVoucher(int VoucherID, com.electronic.genfarma.Voucher voucher) {
    return 0;
    }
    
}
