/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.niit.EVS.DAO;

import com.electronic.genfarma.Employee;
import java.util.List;

/**
 *
 * @author Prateek
 */
public interface EmployeeDAO {
    int Employee (Employee employee);
    
    
   int deleteEmployee(int employeeID);
   List<Employee> getEmployee();
   Employee getEmployeeByID(int employeeID);
   int updateEmployee(int employeeID, Employee employee);
    
}
